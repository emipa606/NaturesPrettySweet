<a href="http://www.kamicomics.com/mods/tkkn-natures-pretty-sweet/">DOWNLOAD LINKS</a>  |  <a href="https://patreon.com/tkkntkkn">Patreon</a>  |  <a href="http://ko-fi.com/kamicomics">Buy me a coffee or beer</a>

### 2-27-2020 Update

Updated everything to work on 1.1 as far as creating a new colony (still tracking down and fixing any gameplay issues)

Fixed issue w/ wildflower and superbloom labels. Fixed snailhead coverage warning.

1.1 only: Made swimming optional (look under settings). 
As of now, I'm fixing any "def" or translation issues for 1.0, but for scripts I'm doing only 1.1

##Personal note and the future of the mod:

Last year was a little crazy, but I'm back on this project. Thank you to everyone who's been patient and has enjoyed this mod. I'm excited to get some stuff out for this year! Because last year was so rough, I'm adding a wiki here about how to patch and add stuff for the mod if anyone wants to. It's mostly to make mods compatible with each other. A few people reached out to me asking what my plans with the mod were, and I answered that I was working on splitting it into modules, so people could download only what they wanted. Splitting this turned into a nightmare, and that plan is on hiatus. I want to add new stuff to the mod and get it more stable, so I'm going to do that!

# Nature's Pretty Sweet:

## What it does:

<a href="http://www.kamicomics.com/mods/tkkn-natures-pretty-sweet/">Read full list of changes and additions here</a>

Adds additional terrain elements, weather, and biomes. It also updates the map/gameplay in response to weather, giving a more wild, untamed and alive feeling to each map.

Most of the elements were directly inspired by places I’ve camped in the US.

There are also new resources, items, dangers, natural protection from raids and other effects. Resources can be harvested to get items, which can be sold or consumed.

There are a few new gameplay elements, but I've tried to make all of that optional. Check the menu to see all the options!

<a href="http://www.kamicomics.com/mods/tkkn-natures-pretty-sweet/">Read full list of changes and additions here</a>

## Performance notes:

Some of the weather effects might cause a little bit of lag (at high speeds or if you’re really zoomed out) but you can turn them off in the options.

I've tested and had no major issues running  mod on a Lenovo Ideapad and a Surface 4.

## Old save information:

Most features require a new save, because they need world generation to work.

Most new elements will generate in the standard biomes, but there are some biomes that guarantee new features, and a few elements are ONLY available in some biomes. 

<a href="http://www.kamicomics.com/mods/tkkn-natures-pretty-sweet/">Read full list of changes and additions here</a>  |  <a href="http://www.kamicomics.com/mods/tkkn-natures-pretty-sweet/">DOWNLOAD LINKS</a>  |  <a href="https://patreon.com/tkkntkkn">Patreon</a>  |  <a href="http://ko-fi.com/kamicomics">Buy me a coffee or beer</a>