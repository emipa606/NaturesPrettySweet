﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TKKN_NPS
{
	public class TKKN_Holder
	{
		public static HashSet<string> modsPatched = new HashSet<string>();

	}
}
