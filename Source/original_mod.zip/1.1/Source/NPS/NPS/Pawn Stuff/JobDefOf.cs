﻿using System;
using Verse;
using RimWorld;

namespace TKKN_NPS
{
	[DefOf]
	public static class JobDefOf
	{
		public static JobDef TKKN_RelaxSpring;
		public static JobDef TKKN_GoSwimming;
		public static JobDef TKKN_DryOff;
		

	}
}