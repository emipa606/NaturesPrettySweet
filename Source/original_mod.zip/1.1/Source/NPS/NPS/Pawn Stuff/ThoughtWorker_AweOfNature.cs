﻿/*

using Verse;
using RimWorld;

namespace TKKN_NPS
{
    class ThoughtWorker_NearNPS : ThoughtWorker
    {

        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            return ThoughtState.ActiveAtStage(0);
        }
    }
}
*/