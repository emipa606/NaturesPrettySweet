﻿using RimWorld;
using System;
using Verse;
using System.Collections.Generic;


namespace TKKN_NPS
{
	public static class ElementSpawnDefOf
	{
//		public static ElementSpawnDef TKKN_SpawnLavaSprings;
		public static ElementSpawnDef TKKN_SpawnSaltCrystals;
		public static ElementSpawnDef TKKN_SpawnHotSprings;
		public static ElementSpawnDef TKKN_SpawnColdSprings;
		public static ElementSpawnDef TKKN_SpawnDeadRedwoods;
	}
}
