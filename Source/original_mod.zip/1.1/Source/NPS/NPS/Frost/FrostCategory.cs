﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TKKN_NPS
{
	public enum FrostCategory : byte
	{
		None,
		Dusting,
		Thin,
		Medium,
		Thick,
		Frost
	}
}
